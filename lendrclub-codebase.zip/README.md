# LendR Protocol

Decentralized Bitcoin-backed lending on Polygon.

Repo structure:
- `contracts/`: Smart contracts (Solidity)
- `frontend/`: Web UI (React/Web3)
- `docs/`: Whitepaper, pitch deck, tokenomics
