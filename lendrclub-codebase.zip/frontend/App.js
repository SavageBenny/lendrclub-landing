// Placeholder for frontend app (React)
import React from 'react';

function App() {
  return <h1>LendR dApp Coming Soon</h1>;
}

export default App;